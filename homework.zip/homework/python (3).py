import requests
def site(URL):
    mane = requests.get(URL)
    if 200 <= mane.status_code < 400:
        print(f'Сайт доступен! код ответа: {mane.status_code}')
    else:
        print(f'Сайт недоступен! Код: {mane.status_code}')
URL = input('Введите URL: ')
site(URL)