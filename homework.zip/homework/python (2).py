import time
import os

while True:
    os.system('cls' if os.name == 'nt' else 'clear')
    times = time.strftime("%H:%M:%S")
    print(times)
    time.sleep(1)
