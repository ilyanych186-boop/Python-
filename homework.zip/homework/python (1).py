import random
import colorama

counter = 0
print('Привет! Это игра "Угадай число"')
colorama.init()

while True:
    pc = random.randint(1,100)
    player = int(input('Введи число от 1 до 100: '))
    if player > pc:
        print(colorama.Fore.RED + 'Слишком много!')
        counter += 1
    elif player < pc:
        print(colorama.Fore.BLUE + 'Слишком мало!')
        counter += 1
    else:
        print(colorama.Fore.GREEN + f'Поздравляю! Вы справились за {counter} попыток')